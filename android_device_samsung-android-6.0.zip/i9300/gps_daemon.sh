#shellscript as this is the only way selinux will allow this to proceed
/system/bin/glgps -c /system/etc/gps.xml
