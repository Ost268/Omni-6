// STLport configuration file
// It is internal STLport header - DO NOT include it directly

#define _STLP_NO_MEMBER_TEMPLATES             // Compiler does not support member templates
#define _STLP_NO_MEMBER_TEMPLATE_CLASSES      // Compiler does not support member template classes

#define _STLP_HAS_NEW_NEW_HEADER
