using _STLP_OLD_IO_NAMESPACE::strstreambuf;
using _STLP_OLD_IO_NAMESPACE::istrstream;
using _STLP_OLD_IO_NAMESPACE::ostrstream;
using _STLP_OLD_IO_NAMESPACE::strstream;
